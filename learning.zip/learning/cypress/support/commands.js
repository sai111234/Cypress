// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

/// <reference types="cypress" />

/// <reference types="cypress-xpath" />

import 'cypress-iframe';

Cypress.Commands.add('handleNewWindow', (clickSelector) => {
  cy.window().then((win) => {
    // Stubbing window.open to capture the URL
    cy.stub(win, 'open').callsFake((url) => {
      // Log the captured URL for debugging
      console.log('Captured URL:', url);
      // Directly set the location to mimic window open behavior
      win.location.href = url;
      // Return the captured URL
      return url;
    }).as('windowOpen');
    
    // Perform the click action that triggers the new window
    cy.get(clickSelector).click({ force: true });
  });
});
  