describe('Handle Multiple Windows', () => {

  it('should handle new window and interact with element', () => {

    Cypress.on('uncaught:exception', (err, runnable) => {
      // Returning false here prevents Cypress from failing the test
      return false;
    });
    // Visit the main page
    cy.visit('https://www.hyrtutorials.com/p/window-handles-practice.html#google_vignette')

    cy.document().its('readyState').should('eq', 'complete')
    cy.get('#aswift_3').scrollIntoView()
    cy.get('#newWindowBtn').should('be.visible')
    cy.handleNewWindow('#newWindowBtn')
    cy.url().should('eq', 'https://www.hyrtutorials.com/p/basic-controls.html')
    cy.get('#firstName').should('be.visible').type('Magatha da')
    cy.get('#registerbtn').scrollIntoView()
    cy.get('#registerbtn').should('be.visible').click()

    cy.window().then(parentWin => {
      // Close the child window
      parentWin.open('', '_self').close();

      // Ensure focus returns to the parent window
      parentWin.focus();
    });

    cy.get('#newWindowBtn').should('be.visible')
  });

  it('Frames', () => {
    Cypress.on('uncaught:exception', (err, runnable) => {
      // Returning false here prevents Cypress from failing the test
      return false;
    });
    // Visit the main page
    cy.visit('https://demoqa.com/frames')
    cy.document().its('readyState').should('eq', 'complete')
    cy.get('#frame1').scrollIntoView()
    cy.frameLoaded('#frame1')
    cy.iframe('#frame1').find('h1#sampleHeading').should('have.text', 'This is a sample page');
  });


it.skip('Window Handle', () => {
  Cypress.on('uncaught:exception', (err, runnable) => {
    // Returning false here prevents Cypress from failing the test
    return false;
  });
  
  // Visit the main page
  cy.visit('https://demo.automationtesting.in/Windows.html')

  cy.document().its('readyState').should('eq', 'complete')
 
   cy.get('ul.nav.nav-tabs.nav-stacked :nth-child(2)').scrollIntoView()
  cy.get('ul.nav.nav-tabs.nav-stacked :nth-child(2)').should('be.visible')
  cy.get('ul.nav.nav-tabs.nav-stacked :nth-child(2)>a').click({ force: true })
  cy.get('button.btn.btn-primary').should('be.visible')
  //cy.get('button.btn.btn-primary').click({ force: true })

  cy.handleNewWindow('button.btn.btn-primary')

  // Wait for the alias to be set
  //cy.wait(1000);

  // Retrieve the URL alias
  cy.get('@newWindowUrl').then((newWindowUrl) => {
    // Debug: Log the retrieved URL
    console.log('Retrieved URL:', newWindowUrl);
    // Visit the new URL
    cy.visit(newWindowUrl);
  });

});
  
});
