describe('First Test',function(){


    
it('Open browser',function(){
cy.visit('https://www.google.co.in/')
cy.document().its('readyState').should('eq', 'complete');
cy.get('textarea[aria-label="Search"]').type('cypress')
//cy.get('textarea[aria-label="Search"]').type('cypress{enter}')
/*cy.xpath('//a').each($element => {
    cy.wrap($element).invoke('text').then(elementText => {
      if (elementText.trim().toLowerCase() === 'தமிழ்'.toLowerCase()) {
        cy.wrap($element).click();
      }
    });
  });*/

  cy.xpath('//a').its('length').then((size) => {
    cy.log('Number of <a> elements:', size);
  });

  cy.xpath('//a').each($element => {
  cy.log('priting links',  $element.text() );        
     });

   cy.xpath('//a').each($element => {
 if($element.text().toLowerCase()=='தமிழ்'.toLowerCase()){
        cy.wrap($element).click();
      }
  });

//cy.get('input.RNmpXc[value="அதிர்ஷ்டம் என் பக்கம்"]').should('be.visible')


})

it.skip('radio button',function(){
  cy.visit('https://materializecss.com/radio-buttons.html')
  cy.document().should((doc) => {
    const readyState = doc.readyState;
    expect(readyState).to.eq('complete')
  });
  cy.get("div[id='radio'] p:nth-child(2) label:nth-child(1) input:nth-child(1)").should('exist')

  cy.get("div[id='radio'] p:nth-child(2) label:nth-child(1) input:nth-child(1)").should('not.be.checked')
  cy.get("div[id='radio'] p:nth-child(2) label:nth-child(1) input:nth-child(1)").check({force: true})
  cy.get("div[id='radio'] p:nth-child(2) label:nth-child(1) input:nth-child(1)").should('be.checked')
 
  
  })




})
